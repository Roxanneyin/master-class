function xc=fpi(g,x0,k)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
x(1) = x0;
for i=1:k
    x(i+1) = g(x(i));
end
xc=x(k+1);

end

