x1 = [-4:0.1:4];
y1 = fun(x1);
y2 = 0;
plot(x1, y1)
hold on
plot([-4,4], [0,0])
x2 = [-2,-1,0,1,2];
y22 = fun(x2)
% Then we found the three intervals of three different root of this
% function which are: [-2,-1], [-1,0], [1,2]
% Now we want to found the root to six correct decimal places, we found
% them three seperately
% for root in [-2,-1]:
f=@(x) 2*x^3-6*x-1;
vpa(bisect(f,-2,-1,0.0000005),7)
% for root in [-1,0]
vpa(bisect(f,-1,0,0.0000005),6)
% for root in [1,2]
vpa(bisect(f,1,2,0.0000005),7)