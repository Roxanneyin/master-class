function [ y ] = fun( x )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
y = 2.*x.^3-6.*x-1;

end

