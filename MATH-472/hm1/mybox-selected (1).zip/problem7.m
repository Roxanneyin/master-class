g=@(x) cos(x)*cos(x)
for j=1:300
    if vpa(fpi(g,0,j),6)-vpa(fpi(g,0,j-1),6) == 0
        break
    end
end
j
r = vpa(fpi(g,0,j),6)
S = abs(-2*cos(r)*sin(r))